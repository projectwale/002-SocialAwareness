import psycopg2
def dbConnection():
    return psycopg2.connect('postgres://admin:UcdviR1GgkEPr89bSAx77bfXbCsFL0VX@dpg-cjlqcc8cfp5c739u75r0-a.oregon-postgres.render.com/socailawareness_1ec1')


conn = dbConnection()
cur = conn.cursor()
sql='''DROP TABLE IF EXISTS comments;'''
cur.execute(sql)

sql = "CREATE TABLE comments (name VARCHAR(255), address VARCHAR(255))"



sql='''CREATE TABLE comments (
  id int(255) NOT NULL auto_increment,
  uname varchar(255) default NULL,
  lname varchar(255) default NULL,
  idofpost varchar(255) default NULL,
  timestamp varchar(255) default NULL,
  comment longtext,
  commenter varchar(255) default NULL,
  time varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;'''
cur.execute(sql)